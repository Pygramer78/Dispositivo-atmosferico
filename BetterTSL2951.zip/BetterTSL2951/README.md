# Welcome to Better Libraries Extension for Arduino!
These libraries that i made are for the sensors MLX90615, TSL2951, BMP280 and AHT20.

# Who made this?
Pygramer78, is the one who started all of these.

### Links to install all the libraries
AHT20: https://github.com/dvarrel/AHT20 \
TSL2591: https://github.com/adafruit/Adafruit_TSL2591_Library \
BMP280: https://github.com/adafruit/Adafruit_BMP280_Library \
MLX90615: https://github.com/skiselev/MLX90615
