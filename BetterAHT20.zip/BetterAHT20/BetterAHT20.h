#ifndef AHT20
#define AHT20

void AHT20_readTemperature(void);
void AHT20_readHumidity(void);
void AHT20_read(void);
void AHT20_init(void);

#endif