#ifndef BMP_280
#define BMP_280

void BMP280_init(void);
void BMP280_configure(void);
void BMP280_readTemperature(void);
void BMP280_readPressure(void);
void BMP280_readAltitude(float hpa);

#endif