#include <Arduino.h>

#include "better_AHT20.h"



void AHT20_readTemperature(void) {
  float temperature = aht20.getTemperature();
  Serial.print("T: ");
  Serial.print(temperature, 2);
  Serial.print(" *C");
}

void AHT20_readHumidity(void) {
  float humidity = aht20.getHumidity();
  Serial.print("Humidity: ");
  Serial.print(humidity, 2);
  Serial.print(" %");
}

void AHT20_read(void) {
  AHT20_readTemperature();
  AHT20_readHumidity();
}
void AHT20_init(void) {
  Wire.begin();
  Serial.println(F("Buscando AHT20..."));
  if (aht20.begin()) {
    Serial.println("AHT20 encontrado!");
  } else {
    Serial.println("AHT20 no encontrado, congelando...");
    while (true)
      ;
  }
}